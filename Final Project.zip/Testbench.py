# -*- coding: utf-8 -*-
"""
Created on Wed Dec 12 23:49:52 2018

@author: koyyk_000
"""

#given S
#
#for i=1:3
#
#   split S into S_train (80%) and S_test (20%)
#
#     train Classifier 1 using S_train with cross-validation, report Classifier 1's cross-validation errors (S_train) and test error (S_test)
#
#     train Classifier 2 using S_train with cross-validation, report Classifier 2's cross-validation errors (S_train) and test error (S_test)
#
#     train Classifier 3 using S_train with cross-validation, report Classifier 3's cross-validation errors (S_train) and test error (S_test)
#
#end
#
#compute the averaged test error for Classifier 1
#
#compute the averaged test error for Classifier 2
#
#compute the averaged test error for Classifier 3